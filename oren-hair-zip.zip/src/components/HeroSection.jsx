import React from 'react';
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ChevronDown, Scissors } from "lucide-react";

export default function HeroSection({ onBookClick }) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=1920&q=80"
          alt="מספרת גברים מודרנית עם כיסאות ברברשופ ואווירה אלגנטית"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#3D2B1F]/90 via-[#3D2B1F]/70 to-[#FAF8F5]" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-1/4 left-10 w-32 h-32 border border-[#F5F5DC]/20 rounded-full animate-pulse hidden lg:block" />
      <div className="absolute bottom-1/4 right-10 w-48 h-48 border border-[#F5F5DC]/10 rounded-full hidden lg:block" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-[#F5F5DC]/20 border border-[#F5F5DC]/40 rounded-lg px-4 py-2 mb-8">
            <Scissors className="w-4 h-4 text-[#F5F5DC]" />
            <span className="text-[#F5F5DC] text-sm font-medium">מספרה פרימיום לגברים</span>
          </div>

          {/* Main Title */}
          <h1 className="text-5xl md:text-7xl font-bold text-[#F5F5DC] mb-6 leading-tight font-serif">
            Oren
            <span className="block text-[#EADDCA]">
              Hairstylish
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-[#F5F5DC]/90 mb-4 font-light">
            מומחה בעיצוב הזקן והשיער
          </p>
          <p className="text-lg text-[#F5F5DC]/70 mb-10 max-w-2xl mx-auto">
            שירות ומקצועיות ברמה הגבוהה ביותר במרכז עסקים עזריאלי חולון
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={onBookClick}
              size="lg"
              className="bg-[#1A1A1A] hover:bg-[#3D2B1F] text-[#F5F5DC] font-bold text-lg px-10 py-6 rounded-lg shadow-xl"
            >
              קבע תור עכשיו
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
              className="border-[#F5F5DC]/50 text-[#F5F5DC] hover:bg-[#F5F5DC]/10 font-medium text-lg px-10 py-6 rounded-lg"
            >
              ראה שירותים
            </Button>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="flex flex-col items-center gap-2 text-[#F5F5DC]/60"
          >
            <span className="text-xs">גלול למטה</span>
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}