import React from 'react';
import { motion } from "framer-motion";
import { Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SoldierDiscountSection({ onBookClick }) {
  return (
    <section className="py-16 bg-[#3D2B1F] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-[#F5F5DC] rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-[#EADDCA] rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-[#F5F5DC]/20 border border-[#F5F5DC]/40 rounded-lg px-5 py-2 mb-6">
            <Shield className="w-5 h-5 text-[#F5F5DC]" />
            <span className="text-[#F5F5DC] font-semibold">מבצע מיוחד לחיילים</span>
            <Sparkles className="w-4 h-4 text-[#F5F5DC]" />
          </div>

          {/* Content */}
          <h2 className="text-3xl md:text-4xl font-bold text-[#F5F5DC] mb-4 font-serif">
            תספורת חיילים במחיר מיוחד
          </h2>
          <p className="text-[#F5F5DC]/70 mb-8 max-w-xl mx-auto">
            אנחנו מעריכים את השירות שלכם! הציגו תעודת חייל ותקבלו תספורת מקצועית במחיר מוזל
          </p>

          {/* Price Card */}
          <div className="inline-block bg-[#FAF8F5] rounded-2xl p-8 border-2 border-[#EADDCA] shadow-2xl">
            <div className="flex items-center justify-center gap-6">
              <div className="text-right">
                <p className="text-[#3D2B1F]/60 text-sm mb-1">מחיר רגיל</p>
                <p className="text-2xl text-[#3D2B1F]/40 line-through">₪70</p>
              </div>
              <div className="w-px h-16 bg-[#EADDCA]" />
              <div className="text-right">
                <p className="text-[#3D2B1F] text-sm mb-1 font-medium">מחיר לחיילים</p>
                <p className="text-5xl font-bold text-[#3D2B1F]">₪50</p>
              </div>
            </div>
            <p className="text-green-600 text-sm mt-4 font-semibold">חיסכון של ₪20!</p>
          </div>

          {/* CTA */}
          <div className="mt-8">
            <Button
              onClick={() => onBookClick("תספורת חיילים")}
              className="bg-[#1A1A1A] hover:bg-[#F5F5DC] hover:text-[#1A1A1A] text-[#F5F5DC] font-bold px-8 py-6 text-lg rounded-lg shadow-xl transition-all"
            >
              <Shield className="w-5 h-5 ml-2" />
              קבע תור עכשיו
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}