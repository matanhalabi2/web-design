import React from 'react';
import { Instagram } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Footer() {
  return (
    <footer className="bg-[#3D2B1F] border-t border-[#3D2B1F] py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#F5F5DC] flex items-center justify-center">
              <span className="text-[#3D2B1F] font-bold text-lg font-serif">O</span>
            </div>
            <div className="text-right">
              <h3 className="text-lg font-bold text-[#F5F5DC] font-serif">Oren Hairstylish</h3>
              <p className="text-xs text-[#F5F5DC]/60">Premium Barbershop</p>
            </div>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6">
            <a
              href="https://instagram.com/oren_rubenov"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[#F5F5DC]/80 hover:text-[#F5F5DC] transition-colors"
            >
              <Instagram className="w-5 h-5" />
              <span>@oren_rubenov</span>
            </a>
            <Link 
              to={createPageUrl('Accessibility')}
              className="text-[#F5F5DC]/80 hover:text-[#F5F5DC] transition-colors text-sm"
            >
              הצהרת נגישות
            </Link>
          </div>

          {/* Copyright */}
          <p className="text-[#F5F5DC]/60 text-sm">
            © {new Date().getFullYear()} Oren Hairstylish. כל הזכויות שמורות.
          </p>
        </div>
      </div>
    </footer>
  );
}