import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { X, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';

export default function BookingCalendar({ isOpen, onClose }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      checkAuth();
      
      // Listen for Calendly events
      const handleMessage = (e) => {
        if (e.data.event && e.data.event.indexOf('calendly') === 0) {
          if (e.data.event === 'calendly.event_scheduled') {
            setShowSuccess(true);
            setTimeout(() => {
              setShowSuccess(false);
              onClose();
            }, 4000);
          }
        }
      };
      
      window.addEventListener('message', handleMessage);
      return () => window.removeEventListener('message', handleMessage);
    }
  }, [isOpen]);

  const checkAuth = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (err) {
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.pathname);
  };

  const handleClose = () => {
    setShowSuccess(false);
    onClose();
  };

  // Build Calendly URL with pre-filled data
  const getCalendlyUrl = () => {
    const baseUrl = 'https://calendly.com/orenhairstylish';
    if (!user) return baseUrl;
    
    const params = new URLSearchParams({
      name: user.full_name || '',
      email: user.email || '',
      a1: user.phone || '' // Custom answer field for phone
    });
    
    return `${baseUrl}?${params.toString()}`;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#3D2B1F]/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#FAF8F5] rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden relative"
          >
            {/* Header */}
            <div className="bg-[#FAF8F5] border-b border-[#EADDCA] p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-[#3D2B1F] font-serif">קביעת תור</h2>
              <button
                onClick={handleClose}
                className="w-10 h-10 rounded-lg bg-[#EADDCA] hover:bg-[#3D2B1F] hover:text-[#F5F5DC] transition-colors flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Success Overlay */}
            <AnimatePresence>
              {showSuccess && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-[#3D2B1F]/95 backdrop-blur-sm flex items-center justify-center z-50"
                >
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-center p-8"
                  >
                    <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle2 className="w-12 h-12 text-green-600" />
                    </div>
                    <h3 className="text-3xl font-bold text-[#F5F5DC] mb-3 font-serif">
                      תודה יאח, אורן מחכה לך!
                    </h3>
                    <p className="text-[#F5F5DC]/80 text-lg">
                      אישור נשלח למייל שלך
                    </p>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Content */}
            <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 100px)' }}>
              {isLoading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#3D2B1F] border-t-transparent"></div>
                </div>
              ) : !user ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-12"
                >
                  <h3 className="text-2xl font-bold text-[#3D2B1F] mb-4 font-serif">
                    התחברות נדרשת
                  </h3>
                  <p className="text-[#3D2B1F]/70 mb-8">
                    יש להתחבר כדי לקבוע תור
                  </p>
                  <Button
                    onClick={handleLogin}
                    className="bg-[#1A1A1A] hover:bg-[#3D2B1F] text-[#F5F5DC] font-bold px-8 py-6 text-lg rounded-lg"
                  >
                    התחבר לקביעת תור
                  </Button>
                </motion.div>
              ) : (
                <div className="calendly-inline-widget" style={{ minHeight: '700px', height: '100%' }}>
                  <iframe
                    src={getCalendlyUrl()}
                    width="100%"
                    height="700"
                    frameBorder="0"
                    title="קביעת תור"
                    style={{ border: 'none' }}
                  />
                  <style>{`
                    .calendly-inline-widget iframe {
                      border-radius: 8px;
                    }
                    /* Hide Calendly branding and cookie banner */
                    .calendly-badge-widget,
                    .calendly-cookie-banner {
                      display: none !important;
                    }
                  `}</style>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}