import React, { useState } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

const galleryImages = [
  {
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698622ee274d8512a7e4737e/cd839e27a_8b96346e-8f90-4d30-9bf5-cfd2e3bf6acb.jpg",
    title: "פייד מתולתל"
  },
  {
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698622ee274d8512a7e4737e/bdf07927f_20ca27ce-bad3-490e-86df-c705a64ff413.jpg",
    title: "סקין פייד עם קו"
  },
  {
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698622ee274d8512a7e4737e/35287c3a9_57d65e47-693c-4e97-bccc-51d7bd6f66f7.jpg",
    title: "תספורת מתולתלת"
  },
  {
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698622ee274d8512a7e4737e/4225384e3_107d14ab-f5f8-4891-87d5-10e86ac487b6.jpg",
    title: "עיצוב V בעורף"
  },
  {
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698622ee274d8512a7e4737e/8b55bfbdc_osher.jpg",
    title: "פייד קלאסי"
  }
];

export default function GallerySection() {
  const [selectedImage, setSelectedImage] = useState(null);

  return (
    <section id="gallery" className="py-24 bg-[#EADDCA]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-[#3D2B1F]/70 text-sm font-medium tracking-wider uppercase mb-4 block">
            העבודות שלנו
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-[#3D2B1F] mb-6 font-serif">
            גלריה
          </h2>
          <p className="text-[#3D2B1F]/60 max-w-2xl mx-auto">
            צפו בעבודות האחרונות שלנו וקבלו השראה לתספורת הבאה שלכם
          </p>
        </motion.div>

        {/* Professional Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {galleryImages.map((image, index) => {
            // Create varied sizes for visual interest
            const isLarge = index === 0 || index === 3;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative group cursor-pointer overflow-hidden rounded-lg border-2 border-[#1A1A1A] shadow-lg shadow-[#3D2B1F]/10 ${
                  isLarge ? 'md:row-span-2 aspect-[3/4]' : 'aspect-square'
                }`}
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#3D2B1F]/90 via-[#3D2B1F]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-[#F5F5DC] font-semibold text-lg">{image.title}</h3>
                  <p className="text-[#EADDCA] text-sm mt-1">לחץ לצפייה</p>
                </div>
                {/* Corner Accent */}
                <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-[#F5F5DC]/50 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.div>
            );
          })}
        </div>

        {/* Instagram CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <a
            href="https://instagram.com/oren_rubenov"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-[#3D2B1F] hover:text-[#3D2B1F]/70 transition-colors font-medium"
          >
            <span>עוד תמונות באינסטגרם שלנו</span>
            <span>@oren_rubenov</span>
          </a>
        </motion.div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#3D2B1F]/95 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button
              className="absolute top-6 right-6 w-12 h-12 rounded-lg bg-[#F5F5DC] flex items-center justify-center hover:bg-[#EADDCA] transition-colors"
              onClick={() => setSelectedImage(null)}
            >
              <X className="w-6 h-6 text-[#3D2B1F]" />
            </button>
            <motion.img
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              src={selectedImage.url}
              alt={selectedImage.title}
              className="max-w-full max-h-[85vh] object-contain rounded-lg border-2 border-[#1A1A1A]"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}