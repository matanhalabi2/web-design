import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { X, Scissors, Calendar, Clock, User, Phone, Check, ChevronRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";
import { format, addDays, isSameDay, getDay } from "date-fns";
import { he } from "date-fns/locale";

const services = [
  { name: "תספורת גברים", price: 70, duration: 45 },
  { name: "תספורת חיילים", price: 50, duration: 30 },
  { name: "עיצוב זקן", price: 20, duration: 15 }
];

// Working hours by day of week (0 = Sunday)
const workingHours = {
  0: { start: 12, end: 19 }, // Sunday
  1: { start: 12, end: 19 }, // Monday
  2: null, // Tuesday - closed
  3: { start: 12, end: 19 }, // Wednesday
  4: { start: 12, end: 19 }, // Thursday
  5: { start: 12, end: 15 }, // Friday
  6: null // Saturday - closed
};

export default function BookingModal({ isOpen, onClose, preselectedService }) {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [existingAppointments, setExistingAppointments] = useState([]);

  useEffect(() => {
    if (preselectedService) {
      const service = services.find(s => s.name === preselectedService);
      if (service) {
        setSelectedService(service);
        setStep(2);
      }
    }
  }, [preselectedService]);

  useEffect(() => {
    if (isOpen) {
      loadExistingAppointments();
    }
  }, [isOpen, selectedDate]);

  const loadExistingAppointments = async () => {
    try {
      const appointments = await base44.entities.Appointment.list();
      setExistingAppointments(appointments.filter(a => a.status !== 'cancelled'));
    } catch (error) {
      console.error('Error loading appointments:', error);
    }
  };

  const getAvailableDates = () => {
    const dates = [];
    for (let i = 0; i < 14; i++) {
      const date = addDays(new Date(), i);
      const dayOfWeek = getDay(date);
      if (workingHours[dayOfWeek]) {
        dates.push(date);
      }
    }
    return dates;
  };

  const getAvailableTimes = () => {
    if (!selectedDate || !selectedService) return [];
    
    const dayOfWeek = getDay(selectedDate);
    const hours = workingHours[dayOfWeek];
    if (!hours) return [];

    const times = [];
    const slotDuration = 30; // 30 minute slots
    
    for (let hour = hours.start; hour < hours.end; hour++) {
      for (let minute = 0; minute < 60; minute += slotDuration) {
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        
        // Check if this slot is already booked
        const dateString = format(selectedDate, 'yyyy-MM-dd');
        const isBooked = existingAppointments.some(
          apt => apt.date === dateString && apt.time === timeString
        );
        
        if (!isBooked) {
          times.push(timeString);
        }
      }
    }
    return times;
  };

  const handleSubmit = async () => {
    if (!customerName || !customerPhone) return;
    
    setIsSubmitting(true);
    try {
      await base44.entities.Appointment.create({
        customer_name: customerName,
        customer_phone: customerPhone,
        service: selectedService.name,
        service_price: selectedService.price,
        date: format(selectedDate, 'yyyy-MM-dd'),
        time: selectedTime,
        status: 'pending'
      });
      setIsSuccess(true);
    } catch (error) {
      console.error('Error creating appointment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetAndClose = () => {
    setStep(1);
    setSelectedService(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setCustomerName('');
    setCustomerPhone('');
    setIsSuccess(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={resetAndClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-zinc-900 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-zinc-800"
          onClick={(e) => e.stopPropagation()}
          dir="rtl"
        >
          {/* Header */}
          <div className="sticky top-0 bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between z-10">
            <h2 className="text-xl font-bold text-white">הזמנת תור</h2>
            <button
              onClick={resetAndClose}
              className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center hover:bg-zinc-700 transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Progress Steps */}
          {!isSuccess && (
            <div className="p-4 border-b border-zinc-800">
              <div className="flex items-center justify-between">
                {[1, 2, 3].map((s) => (
                  <div key={s} className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                      step >= s ? 'bg-amber-500 text-black' : 'bg-zinc-800 text-zinc-500'
                    }`}>
                      {s}
                    </div>
                    {s < 3 && (
                      <div className={`w-16 md:w-24 h-1 mx-2 rounded transition-colors ${
                        step > s ? 'bg-amber-500' : 'bg-zinc-800'
                      }`} />
                    )}
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-2 text-xs text-zinc-500">
                <span>שירות</span>
                <span>תאריך ושעה</span>
                <span>פרטים</span>
              </div>
            </div>
          )}

          {/* Content */}
          <div className="p-6">
            {isSuccess ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-8"
              >
                <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
                  <Check className="w-10 h-10 text-green-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">התור נקבע בהצלחה!</h3>
                <p className="text-zinc-400 mb-6">
                  {selectedService?.name} בתאריך {selectedDate && format(selectedDate, 'd בMMMM', { locale: he })} בשעה {selectedTime}
                </p>
                <Button onClick={resetAndClose} className="bg-amber-500 hover:bg-amber-600 text-black font-bold">
                  סגור
                </Button>
              </motion.div>
            ) : (
              <>
                {/* Step 1: Select Service */}
                {step === 1 && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Scissors className="w-5 h-5 text-amber-500" />
                      בחר שירות
                    </h3>
                    {services.map((service) => (
                      <button
                        key={service.name}
                        onClick={() => {
                          setSelectedService(service);
                          setStep(2);
                        }}
                        className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                          selectedService?.name === service.name
                            ? 'border-amber-500 bg-amber-500/10'
                            : 'border-zinc-800 hover:border-zinc-700 bg-zinc-800/50'
                        }`}
                      >
                        <div className="text-right">
                          <h4 className="text-white font-medium">{service.name}</h4>
                          <p className="text-zinc-500 text-sm">{service.duration} דקות</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-xl font-bold text-amber-500">₪{service.price}</span>
                          <ChevronLeft className="w-5 h-5 text-zinc-500" />
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* Step 2: Select Date & Time */}
                {step === 2 && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-amber-500" />
                      בחר תאריך
                    </h3>
                    
                    {/* Date Selection */}
                    <div className="grid grid-cols-4 gap-2">
                      {getAvailableDates().map((date) => (
                        <button
                          key={date.toISOString()}
                          onClick={() => {
                            setSelectedDate(date);
                            setSelectedTime(null);
                          }}
                          className={`p-3 rounded-xl border text-center transition-all ${
                            selectedDate && isSameDay(date, selectedDate)
                              ? 'border-amber-500 bg-amber-500/10'
                              : 'border-zinc-800 hover:border-zinc-700'
                          }`}
                        >
                          <div className="text-xs text-zinc-500">
                            {format(date, 'EEE', { locale: he })}
                          </div>
                          <div className="text-lg font-bold text-white">
                            {format(date, 'd')}
                          </div>
                          <div className="text-xs text-zinc-500">
                            {format(date, 'MMM', { locale: he })}
                          </div>
                        </button>
                      ))}
                    </div>

                    {/* Time Selection */}
                    {selectedDate && (
                      <>
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                          <Clock className="w-5 h-5 text-amber-500" />
                          בחר שעה
                        </h3>
                        <div className="grid grid-cols-4 gap-2">
                          {getAvailableTimes().map((time) => (
                            <button
                              key={time}
                              onClick={() => setSelectedTime(time)}
                              className={`p-3 rounded-xl border text-center transition-all ${
                                selectedTime === time
                                  ? 'border-amber-500 bg-amber-500/10'
                                  : 'border-zinc-800 hover:border-zinc-700'
                              }`}
                            >
                              <span className="text-white font-medium">{time}</span>
                            </button>
                          ))}
                        </div>
                        {getAvailableTimes().length === 0 && (
                          <p className="text-zinc-500 text-center">אין תורים פנויים בתאריך זה</p>
                        )}
                      </>
                    )}

                    {/* Navigation */}
                    <div className="flex gap-3 pt-4">
                      <Button
                        variant="outline"
                        onClick={() => setStep(1)}
                        className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
                      >
                        <ChevronRight className="w-4 h-4 ml-2" />
                        חזור
                      </Button>
                      <Button
                        onClick={() => setStep(3)}
                        disabled={!selectedDate || !selectedTime}
                        className="flex-1 bg-amber-500 hover:bg-amber-600 text-black font-bold disabled:opacity-50"
                      >
                        המשך
                        <ChevronLeft className="w-4 h-4 mr-2" />
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step 3: Customer Details */}
                {step === 3 && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <User className="w-5 h-5 text-amber-500" />
                      פרטים אישיים
                    </h3>

                    {/* Summary */}
                    <div className="bg-zinc-800/50 rounded-xl p-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-zinc-400">שירות:</span>
                        <span className="text-white">{selectedService?.name}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-zinc-400">תאריך:</span>
                        <span className="text-white">{selectedDate && format(selectedDate, 'd בMMMM yyyy', { locale: he })}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-zinc-400">שעה:</span>
                        <span className="text-white">{selectedTime}</span>
                      </div>
                      <div className="flex justify-between text-sm pt-2 border-t border-zinc-700">
                        <span className="text-zinc-400">מחיר:</span>
                        <span className="text-amber-500 font-bold">₪{selectedService?.price}</span>
                      </div>
                    </div>

                    {/* Form */}
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm text-zinc-400 block mb-2">שם מלא</label>
                        <Input
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="הזן את שמך"
                          className="bg-zinc-800 border-zinc-700 text-white text-right"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-zinc-400 block mb-2">טלפון</label>
                        <Input
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="050-0000000"
                          className="bg-zinc-800 border-zinc-700 text-white text-right"
                          dir="ltr"
                        />
                      </div>
                    </div>

                    {/* Navigation */}
                    <div className="flex gap-3 pt-4">
                      <Button
                        variant="outline"
                        onClick={() => setStep(2)}
                        className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
                      >
                        <ChevronRight className="w-4 h-4 ml-2" />
                        חזור
                      </Button>
                      <Button
                        onClick={handleSubmit}
                        disabled={!customerName || !customerPhone || isSubmitting}
                        className="flex-1 bg-amber-500 hover:bg-amber-600 text-black font-bold disabled:opacity-50"
                      >
                        {isSubmitting ? 'שולח...' : 'אשר הזמנה'}
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}