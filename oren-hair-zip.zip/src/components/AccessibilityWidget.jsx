import React, { useState } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Accessibility, X, ZoomIn, ZoomOut, Contrast, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AccessibilityWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  const [highContrast, setHighContrast] = useState(false);

  const increaseFontSize = () => {
    const newSize = Math.min(fontSize + 10, 150);
    setFontSize(newSize);
    document.documentElement.style.fontSize = `${newSize}%`;
  };

  const decreaseFontSize = () => {
    const newSize = Math.max(fontSize - 10, 80);
    setFontSize(newSize);
    document.documentElement.style.fontSize = `${newSize}%`;
  };

  const toggleContrast = () => {
    setHighContrast(!highContrast);
    if (!highContrast) {
      document.documentElement.style.filter = 'contrast(1.3)';
    } else {
      document.documentElement.style.filter = 'none';
    }
  };

  const resetSettings = () => {
    setFontSize(100);
    setHighContrast(false);
    document.documentElement.style.fontSize = '100%';
    document.documentElement.style.filter = 'none';
  };

  return (
    <div className="fixed bottom-24 left-6 z-50">
      {/* Widget Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="mb-4 bg-white rounded-lg shadow-2xl border-2 border-[#3D2B1F] p-4 w-64"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-[#3D2B1F] text-sm">נגישות</h3>
              <button
                onClick={() => setIsOpen(false)}
                className="text-[#3D2B1F]/60 hover:text-[#3D2B1F]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Font Size Controls */}
              <div className="bg-[#EADDCA]/20 rounded-lg p-3">
                <p className="text-xs text-[#3D2B1F]/70 mb-2 text-right">גודל גופן</p>
                <div className="flex items-center justify-between gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={decreaseFontSize}
                    className="flex-1"
                    disabled={fontSize <= 80}
                  >
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <span className="text-xs font-medium text-[#3D2B1F] min-w-[3rem] text-center">
                    {fontSize}%
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={increaseFontSize}
                    className="flex-1"
                    disabled={fontSize >= 150}
                  >
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* High Contrast Toggle */}
              <Button
                onClick={toggleContrast}
                className={`w-full justify-start gap-2 ${
                  highContrast 
                    ? 'bg-[#3D2B1F] text-[#F5F5DC]' 
                    : 'bg-[#EADDCA]/20 text-[#3D2B1F] hover:bg-[#EADDCA]/40'
                }`}
              >
                <Contrast className="w-4 h-4" />
                <span className="text-sm">ניגודיות גבוהה</span>
              </Button>

              {/* Reset Button */}
              <Button
                onClick={resetSettings}
                variant="outline"
                className="w-full justify-start gap-2 border-[#3D2B1F]/30"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="text-sm">איפוס הגדרות</span>
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1.2, type: "spring" }}
        className="w-14 h-14 bg-[#3D2B1F] rounded-lg flex items-center justify-center shadow-lg hover:bg-[#1A1A1A] transition-colors"
        aria-label="פתח תפריט נגישות"
      >
        <Accessibility className="w-7 h-7 text-[#F5F5DC]" />
      </motion.button>
    </div>
  );
}