import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Instagram, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Header({ onBookClick }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#3D2B1F]/10 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#3D2B1F] flex items-center justify-center">
              <span className="text-[#F5F5DC] font-bold text-xl font-serif">O</span>
            </div>
            <div className="text-right">
              <h1 className="text-xl font-bold text-[#3D2B1F] tracking-wide font-serif">Oren Hairstylish</h1>
              <p className="text-xs text-[#3D2B1F]/70 font-medium">Premium Barbershop</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('services')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors font-medium">
              שירותים
            </button>
            <button onClick={() => scrollToSection('gallery')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors font-medium">
              גלריה
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors font-medium">
              צור קשר
            </button>
            <Link to={createPageUrl('Accessibility')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors font-medium">
              נגישות
            </Link>
          </nav>

          {/* CTA Buttons */}
          <div className="flex items-center gap-3">
            <a
              href="https://instagram.com/oren_rubenov"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex w-10 h-10 rounded-lg bg-[#3D2B1F]/10 items-center justify-center hover:bg-[#3D2B1F]/20 transition-colors"
              aria-label="עקבו אחרינו באינסטגרם"
            >
              <Instagram className="w-5 h-5 text-[#3D2B1F]" />
            </a>
            <Button
              onClick={onBookClick}
              className="bg-[#1A1A1A] hover:bg-[#3D2B1F] text-[#F5F5DC] font-bold px-6 rounded-lg shadow-md"
            >
              קבע תור
            </Button>
            
            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden w-10 h-10 rounded-lg bg-[#3D2B1F]/10 flex items-center justify-center"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-[#3D2B1F]" /> : <Menu className="w-5 h-5 text-[#3D2B1F]" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.nav
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden mt-4 pb-4 border-t border-[#3D2B1F]/10 pt-4"
            >
              <div className="flex flex-col gap-4 text-right">
                <button onClick={() => scrollToSection('services')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors py-2 font-medium">
                  שירותים
                </button>
                <button onClick={() => scrollToSection('gallery')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors py-2 font-medium">
                  גלריה
                </button>
                <button onClick={() => scrollToSection('contact')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors py-2 font-medium">
                  צור קשר
                </button>
                <Link to={createPageUrl('Accessibility')} className="text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors py-2 font-medium">
                  נגישות
                </Link>
                <a
                  href="https://instagram.com/oren_rubenov"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-end gap-2 text-[#3D2B1F]/80 hover:text-[#3D2B1F] transition-colors py-2 font-medium"
                >
                  <span>אינסטגרם</span>
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}