import React from 'react';
import { motion } from "framer-motion";
import { Scissors, Award, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    name: "תספורת גברים",
    price: 70,
    duration: "45 דקות",
    description: "תספורת מקצועית הכוללת שטיפה, עיצוב וייבוש",
    icon: Scissors,
    popular: true
  },
  {
    name: "תספורת חיילים",
    price: 50,
    duration: "30 דקות",
    description: "תספורת מהירה ומקצועית במחיר מיוחד לחיילים",
    icon: Award,
    popular: false
  },
  {
    name: "עיצוב זקן",
    price: 20,
    duration: "15 דקות",
    description: "עיצוב וקיצוץ זקן מקצועי",
    icon: Scissors,
    popular: false
  }
];

export default function ServicesSection({ onBookClick }) {
  return (
    <section id="services" className="py-24 bg-[#FAF8F5] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%233D2B1F' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />
      </div>

      <div className="max-w-6xl mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-[#3D2B1F]/70 text-sm font-medium tracking-wider uppercase mb-4 block">
            השירותים שלנו
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-[#3D2B1F] mb-6 font-serif">
            מחירון שירותים
          </h2>
          <p className="text-[#3D2B1F]/60 max-w-2xl mx-auto">
            כל השירותים כוללים ייעוץ אישי והתאמה מדויקת לסגנון שלך
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative group bg-white rounded-2xl p-8 border transition-all duration-300 shadow-lg shadow-[#3D2B1F]/5 hover:shadow-xl hover:shadow-[#3D2B1F]/10 ${
                service.popular 
                  ? 'border-[#3D2B1F] ring-2 ring-[#3D2B1F]/20' 
                  : 'border-[#EADDCA] hover:border-[#3D2B1F]/30'
              }`}
            >
              {/* Popular Badge */}
              {service.popular && (
                <div className="absolute -top-3 right-6 bg-[#1A1A1A] text-[#F5F5DC] text-xs font-bold px-4 py-1 rounded-lg">
                  פופולרי
                </div>
              )}

              {/* Icon */}
              <div className={`w-14 h-14 rounded-lg flex items-center justify-center mb-6 ${
                service.popular 
                  ? 'bg-[#3D2B1F]' 
                  : 'bg-[#EADDCA]'
              }`}>
                <service.icon className={`w-7 h-7 ${service.popular ? 'text-[#F5F5DC]' : 'text-[#3D2B1F]'}`} />
              </div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-[#3D2B1F] mb-2 font-serif">{service.name}</h3>
              <p className="text-[#3D2B1F]/60 text-sm mb-4">{service.description}</p>
              
              {/* Duration */}
              <div className="flex items-center gap-2 text-[#3D2B1F]/50 text-sm mb-6">
                <Clock className="w-4 h-4" />
                <span>{service.duration}</span>
              </div>

              {/* Price */}
              <div className="flex items-end justify-between">
                <div>
                  <span className="text-4xl font-bold text-[#3D2B1F]">₪{service.price}</span>
                </div>
                <Button
                  onClick={() => onBookClick(service.name)}
                  className={service.popular 
                    ? "bg-[#1A1A1A] hover:bg-[#3D2B1F] text-[#F5F5DC] font-bold rounded-lg" 
                    : "bg-[#EADDCA] hover:bg-[#3D2B1F] text-[#3D2B1F] hover:text-[#F5F5DC] font-bold rounded-lg"
                  }
                >
                  הזמן עכשיו
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}