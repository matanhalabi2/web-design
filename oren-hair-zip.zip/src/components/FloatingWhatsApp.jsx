import React from 'react';
import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";

export default function FloatingWhatsApp() {
  return (
    <motion.a
      href="https://wa.me/972500000000"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ delay: 1, type: "spring" }}
      className="fixed bottom-6 left-6 z-50 w-14 h-14 bg-[#25D366] rounded-lg flex items-center justify-center shadow-lg shadow-[#25D366]/30 hover:bg-[#20BD5A] transition-colors"
    >
      <MessageCircle className="w-7 h-7 text-white" />
      <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#3D2B1F] rounded-full animate-pulse" />
    </motion.a>
  );
}