import React from 'react';

export default function Layout({ children }) {
  return (
    <div className="min-h-screen">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Assistant:wght@300;400;500;600;700&family=Montserrat:wght@300;400;500;600;700&display=swap');
        
        :root {
          --color-beige: #F5F5DC;
          --color-sand: #EADDCA;
          --color-espresso: #3D2B1F;
          --color-matte-black: #1A1A1A;
          --color-warm-white: #FAF8F5;
        }
        
        body {
          font-family: 'Assistant', 'Montserrat', sans-serif;
          background-color: var(--color-warm-white);
        }
        
        h1, h2, h3, .heading-serif {
          font-family: 'Playfair Display', serif;
        }
        
        .font-sans-elegant {
          font-family: 'Montserrat', 'Assistant', sans-serif;
        }
      `}</style>
      {children}
    </div>
  );
}