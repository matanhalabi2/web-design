import React from 'react';
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import SoldierDiscountSection from "@/components/SoldierDiscountSection";
import GallerySection from "@/components/GallerySection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import BookingCalendar from "@/components/BookingCalendar";
import AccessibilityWidget from "@/components/AccessibilityWidget";

export default function Home() {
  const [isBookingOpen, setIsBookingOpen] = React.useState(false);
  const [preSelectedService, setPreSelectedService] = React.useState(null);

  const openBooking = (service) => {
    setPreSelectedService(service);
    setIsBookingOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5]" dir="rtl">
      <title>Oren Hairstylish | מספרת גברים ועיצוב זקן בחולון</title>
      <meta 
        name="description" 
        content="מספרת גברים וברברשופ פרימיום בחולון. תספורות גברים, עיצוב זקן ותספורות חיילים באווירה ייחודית. קבעו תור אונליין בקלות."
      />
      <meta 
        name="keywords" 
        content="מספרה בחולון, ברברשופ, תספורת גברים, עיצוב זקן, תספורת חיילים, מספרת גברים חולון, Oren Hairstylish"
      />
      <Header onBookClick={openBooking} />
      <HeroSection onBookClick={openBooking} />
      <ServicesSection onBookClick={openBooking} />
      <SoldierDiscountSection onBookClick={openBooking} />
      <GallerySection />
      <ContactSection onBookClick={openBooking} />
      <Footer />
      <FloatingWhatsApp />
      <AccessibilityWidget />
      <BookingCalendar 
        isOpen={isBookingOpen} 
        onClose={() => {
          setIsBookingOpen(false);
          setPreSelectedService(null);
        }}
      />
    </div>
  );
}