import React from 'react';
import { motion } from "framer-motion";
import { CheckCircle, Mail, Phone } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Accessibility() {
  return (
    <div className="min-h-screen bg-[#FAF8F5]" dir="rtl">
      <Header onBookClick={() => {}} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg border border-[#EADDCA] p-8 md:p-12"
          >
            {/* Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-[#3D2B1F] mb-4 font-serif">
                הצהרת נגישות
              </h1>
              <p className="text-[#3D2B1F]/70 text-lg">
                Oren Hairstylish - מחויבים לנגישות דיגיטלית
              </p>
            </div>

            {/* Content */}
            <div className="space-y-8 text-[#3D2B1F]/80 leading-relaxed">
              <section>
                <h2 className="text-2xl font-bold text-[#3D2B1F] mb-4 flex items-center gap-2">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  מחויבות לנגישות
                </h2>
                <p className="mb-4">
                  אתר Oren Hairstylish מחויב להבטיח נגישות דיגיטלית לאנשים עם מוגבלויות. 
                  אנו משפרים באופן מתמיד את חווית המשתמש עבור כולם ומיישמים תקני נגישות רלוונטיים.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-[#3D2B1F] mb-4">תקנים</h2>
                <p className="mb-4">
                  האתר נבנה בהתאם לתקן הישראלי (ת"י 5568) ולהנחיות הנגישות WCAG 2.1 ברמה AA.
                  האתר תומך בטכנולוגיות מסייעות כגון:
                </p>
                <ul className="list-disc list-inside space-y-2 mr-4">
                  <li>קוראי מסך (Screen Readers)</li>
                  <li>ניווט באמצעות מקלדת</li>
                  <li>התאמת גודל גופנים</li>
                  <li>ניגודיות צבעים משופרת</li>
                  <li>תמיכה בדפדפנים מובילים</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-[#3D2B1F] mb-4">תכונות נגישות באתר</h2>
                <ul className="list-disc list-inside space-y-2 mr-4">
                  <li>תיוג תמונות עם טקסט חלופי (Alt-text)</li>
                  <li>כותרות מובנות היררכית</li>
                  <li>ניגודיות צבעים עומדת בתקן AA</li>
                  <li>תפריט נגישות לשינוי הגדרות התצוגה</li>
                  <li>קישורים ברורים עם תיאור משמעותי</li>
                  <li>טפסים נגישים עם תוויות ברורות</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-[#3D2B1F] mb-4">פניות והצעות לשיפור</h2>
                <p className="mb-4">
                  אם נתקלתם בבעיית נגישות באתר או שיש לכם הצעות לשיפור, אנא צרו קשר:
                </p>
                <div className="bg-[#EADDCA]/30 rounded-lg p-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-[#3D2B1F]" />
                    <a 
                      href="mailto:orenhairstylish@gmail.com"
                      className="text-[#3D2B1F] hover:text-[#1A1A1A] font-medium"
                    >
                      orenhairstylish@gmail.com
                    </a>
                  </div>
                  <p className="text-sm text-[#3D2B1F]/70">
                    רכז נגישות: אורן רובנוב
                  </p>
                </div>
                <p className="mt-4 text-sm">
                  אנו מתחייבים לטפל בכל פניה בנושא נגישות בתוך 5 ימי עסקים ולעשות כל שביכולתנו 
                  לספק פתרון סביר.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-[#3D2B1F] mb-4">עדכון אחרון</h2>
                <p>
                  הצהרת נגישות זו עודכנה לאחרונה בתאריך: {new Date().toLocaleDateString('he-IL')}
                </p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  );
}