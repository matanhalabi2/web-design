import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const CALENDAR_EMAIL = 'orenhairstylish@gmail.com';
const SLOT_DURATION_MINUTES = 60;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { datetime, customerName, customerPhone, service } = await req.json();
    
    if (!datetime || !customerName || !customerPhone || !service) {
      return Response.json({ 
        error: 'Missing required fields' 
      }, { status: 400 });
    }

    // Get Google Calendar access token
    const accessToken = await base44.asServiceRole.connectors.getAccessToken('googlecalendar');
    
    // Create event in Google Calendar
    const startTime = new Date(datetime);
    const endTime = new Date(startTime.getTime() + SLOT_DURATION_MINUTES * 60000);
    
    const event = {
      summary: `${service} - ${customerName}`,
      description: `טלפון: ${customerPhone}\nשירות: ${service}\nשם: ${customerName}`,
      start: {
        dateTime: startTime.toISOString(),
        timeZone: 'Asia/Jerusalem'
      },
      end: {
        dateTime: endTime.toISOString(),
        timeZone: 'Asia/Jerusalem'
      },
      attendees: [],
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'popup', minutes: 60 },
          { method: 'popup', minutes: 1440 } // 24 hours
        ]
      }
    };
    
    const calendarResponse = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(CALENDAR_EMAIL)}/events`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(event)
      }
    );
    
    if (!calendarResponse.ok) {
      const errorData = await calendarResponse.json();
      throw new Error(`Failed to create calendar event: ${errorData.error?.message || 'Unknown error'}`);
    }
    
    const createdEvent = await calendarResponse.json();
    
    // Save to local database
    await base44.asServiceRole.entities.Appointment.create({
      customer_name: customerName,
      customer_phone: customerPhone,
      service: service,
      date: startTime.toISOString().split('T')[0],
      time: startTime.toTimeString().slice(0, 5),
      status: 'confirmed',
      google_event_id: createdEvent.id
    });
    
    // Send confirmation email
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        from_name: 'Oren Hairstylish',
        to: customerPhone.includes('@') ? customerPhone : `${customerPhone}@example.com`,
        subject: 'אישור תור - Oren Hairstylish',
        body: `
          <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #3D2B1F;">שלום ${customerName},</h2>
            <p>התור שלך אושר בהצלחה!</p>
            <div style="background: #FAF8F5; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p><strong>שירות:</strong> ${service}</p>
              <p><strong>תאריך:</strong> ${startTime.toLocaleDateString('he-IL')}</p>
              <p><strong>שעה:</strong> ${startTime.toTimeString().slice(0, 5)}</p>
            </div>
            <p style="color: #3D2B1F;"><strong>כתובת:</strong> מרכז עסקים עזריאלי חולון, בניין מילר בשמים</p>
            <p>נתראה בקרוב!</p>
            <p style="color: #666; font-size: 12px;">במידה ואתה צריך לבטל או לשנות את התור, אנא צור קשר בטלפון או WhatsApp.</p>
          </div>
        `
      });
    } catch (emailError) {
      console.error('Failed to send email:', emailError);
      // Continue even if email fails
    }
    
    return Response.json({ 
      success: true, 
      eventId: createdEvent.id,
      message: 'התור נקבע בהצלחה'
    });
    
  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});