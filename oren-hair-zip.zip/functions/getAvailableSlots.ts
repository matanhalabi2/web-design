import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const WORKING_HOURS = {
  0: { start: '12:00', end: '19:00' }, // Sunday
  1: { start: '12:00', end: '19:00' }, // Monday
  2: null, // Tuesday - Closed
  3: { start: '12:00', end: '19:00' }, // Wednesday
  4: { start: '12:00', end: '19:00' }, // Thursday
  5: { start: '12:00', end: '15:00' }, // Friday
  6: null  // Saturday - Closed
};

const SLOT_DURATION_MINUTES = 60; // 1 hour per appointment
const CALENDAR_EMAIL = 'orenhairstylish@gmail.com';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { date } = await req.json();
    
    if (!date) {
      return Response.json({ error: 'Date is required' }, { status: 400 });
    }

    // Get Google Calendar access token
    const accessToken = await base44.asServiceRole.connectors.getAccessToken('googlecalendar');
    
    // Parse the date
    const targetDate = new Date(date);
    const dayOfWeek = targetDate.getDay();
    
    // Check if day is working day
    const workingHours = WORKING_HOURS[dayOfWeek];
    if (!workingHours) {
      return Response.json({ slots: [] });
    }
    
    // Generate all possible slots for the day
    const allSlots = [];
    const [startHour, startMinute] = workingHours.start.split(':').map(Number);
    const [endHour, endMinute] = workingHours.end.split(':').map(Number);
    
    let currentTime = new Date(targetDate);
    currentTime.setHours(startHour, startMinute, 0, 0);
    
    const endTime = new Date(targetDate);
    endTime.setHours(endHour, endMinute, 0, 0);
    
    while (currentTime < endTime) {
      allSlots.push(new Date(currentTime));
      currentTime = new Date(currentTime.getTime() + SLOT_DURATION_MINUTES * 60000);
    }
    
    // Get busy times from Google Calendar
    const timeMin = new Date(targetDate);
    timeMin.setHours(0, 0, 0, 0);
    const timeMax = new Date(targetDate);
    timeMax.setHours(23, 59, 59, 999);
    
    const calendarResponse = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(CALENDAR_EMAIL)}/events?` +
      `timeMin=${timeMin.toISOString()}&timeMax=${timeMax.toISOString()}&singleEvents=true`,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    if (!calendarResponse.ok) {
      throw new Error('Failed to fetch calendar events');
    }
    
    const calendarData = await calendarResponse.json();
    const busyEvents = calendarData.items || [];
    
    // Filter out busy slots
    const availableSlots = allSlots.filter(slot => {
      const slotEnd = new Date(slot.getTime() + SLOT_DURATION_MINUTES * 60000);
      
      // Check if slot overlaps with any busy event
      const isAvailable = !busyEvents.some(event => {
        if (!event.start || !event.end) return false;
        
        const eventStart = new Date(event.start.dateTime || event.start.date);
        const eventEnd = new Date(event.end.dateTime || event.end.date);
        
        // Check for overlap
        return (slot < eventEnd && slotEnd > eventStart);
      });
      
      // Also check if slot is in the future
      const now = new Date();
      return isAvailable && slot > now;
    });
    
    // Format slots
    const formattedSlots = availableSlots.map(slot => ({
      time: slot.toTimeString().slice(0, 5),
      datetime: slot.toISOString()
    }));
    
    return Response.json({ slots: formattedSlots });
    
  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});